#include <iostream>

// Inheritance

using namespace std;

class insan{
    public:
    int boy;
    int kilo;
    char * adres;
    public: int yemek(){
        kilo++;
    }
};

class calisan : public insan{ // Inheritance (miras) yapıldı.
    public:
    int maas;
    int zam(int x){
        maas+=x;
    }
};

int main()
{
    calisan veli;
    veli.maas= 5000;
    veli.boy=170;
    veli.kilo=75;
    cout<< "Veli Boy: " << veli.boy << endl;
    cout<< "Veli Kilo: "<< veli.kilo << endl;
    cout<< "Maas: " << veli.maas << endl;
    veli.zam(500);
    veli.yemek();

    cout<< "Maas: " << veli.maas << endl;

}