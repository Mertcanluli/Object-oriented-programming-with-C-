#include <iostream>

using namespace std;

class sekil{
    protected:
    int boy;
    int en;

    public:
    void SetBoy(int boy){
        this->boy=boy;
    }
    void SetEn(int en){
        this->en=en;
    }
    int GetBoy() const{
        return boy;
    }
    int GetEn() const{
        return en;
    }

    virtual int alan(){ //
        cout<< "sekilde alan:"<< endl;
        return 0;
    }

    sekil(int a, int b){
        if(a<0)
        en=0;
        else
        en=a;
        boy=b;
    }
};

class dikdortgen : public sekil{
    public:
    dikdortgen(int a, int b):sekil(a,b){}
    int alan(){ //override
        cout<< "dikdortgen alan: "<< endl;
        return en*boy;
    }
};

class ucgen : public sekil{
    public:
    ucgen(int a, int b) : sekil(a,b){}
    int alan(){ //override. Yani şekil classında bulunan alan tanımını kullanmıyoruz, yeniden tanım yapıyoruz.
        cout<< "Ucgende alan: "<< endl;
        return (en*boy)/2;
    }
};


int main()
{
    ucgen u(4,5);
    dikdortgen d(4,5);
    cout<< "Ucgen alan: "<< u.alan() << endl;
    cout<< "Dikdortgen alan: "<< d.alan() << endl;
    sekil*s;
    s=&u;
    cout<< "Seklin alani(ucgen): "<< s->alan() << endl;
    s=&d;
    cout<< "Seklin alani(dikdortgen): " << s->alan() << endl;

}