#include <iostream>

using namespace std;

class insan{ // Class ismi "İnsan".
    public: 
    int boy;
    int kilo;
    int yas;
};

int main()
{
    insan ali; // Object ismi "ali".
    ali.boy = 175;
    ali.kilo = 80;
    ali.yas = 30;

    cout<< "Boy: "<< ali.boy << "Kilo: " << ali.kilo << "Yas: "<< ali.yas << endl;

    insan veli; // Object ismi "veli".
    veli.boy = 195;
    veli.kilo = 65;
    veli.yas = 64;

    cout<< "Boy: " << veli.boy << "Kilo: " << veli.kilo << "Yas: " << veli.yas << endl;

}