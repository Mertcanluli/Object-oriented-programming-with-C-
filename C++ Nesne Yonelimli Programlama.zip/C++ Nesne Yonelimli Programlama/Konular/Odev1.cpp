#include <iostream>

using namespace std;

/*class dikdortgen{

    public:
     int en;
     int boy;
     int alan()
     {
        return en*boy;
     }
    int cevre()
    {
        return (en+boy)*2;
    } 
};

int main()
{
    dikdortgen kucuk;

    kucuk.en = 50;
    kucuk.boy = 100;
    int alan = kucuk.alan();
    int cevre = kucuk.cevre();

    cout<< "Alan: " << alan<< "Boy: " << cevre << endl;

    dikdortgen buyuk;

    buyuk.en = 150;
    buyuk.boy = 200;
    int alan = buyuk.alan();
    int cevre = buyuk.cevre();

    cout<< "Alan: " << alan<< "Boy: " << cevre << endl;

} */

class dikdortgen{
    public: 
        int en;
        int boy;
        int alan(){
            return en * boy;
        }
        int cevre (){
            return 2*(en+boy);
        }
};
int main(){
    dikdortgen ilk;
    dikdortgen ikinci;
    ilk.en=50;
    ilk.boy=100;
    ikinci.en=150;
    ikinci.boy= 200;
    cout << "ilk dikdortgenin alani:"<< ilk.alan() << " cevresi:" << ilk.cevre() << endl;
    cout << "ikinci dikdortgenin alani:"<< ikinci.alan() << " cevresi:" << ikinci.cevre() << endl;
}