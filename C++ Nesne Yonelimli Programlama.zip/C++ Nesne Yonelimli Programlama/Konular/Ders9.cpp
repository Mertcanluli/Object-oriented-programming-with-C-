#include <iostream>

using namespace std;

class insan{
    public:
    int boy;
    int kilo;

    public:
    void yemek(int kilo){
        this->kilo=this->kilo+kilo;
    }
};

int main(void)
{
    
    insan ali;
    ali.boy=180;
    insan*g;
    g=&ali;
    cout<< ali.boy << endl;
    cout<< g->boy << endl;
    g->kilo=70;
    g->yemek(5);
    cout<< g->kilo << endl;

    return 0;

}