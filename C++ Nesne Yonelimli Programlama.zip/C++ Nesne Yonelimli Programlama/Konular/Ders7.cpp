#include <iostream>

using namespace std;

// Operator Overloading

class dikdortgen{
    private:
    int en;
    int boy;
    
    public:
    void SetBoy(int boy){
        this->boy=boy;
    }
    void SetEn(int en){
        this->en=en;
    }

    int GetBoy()const{return boy;}
    int GetEn()const{return en;}

    dikdortgen operator+(const dikdortgen&d){
        dikdortgen DDortgen;
        DDortgen.boy = this -> boy+d.boy;
        DDortgen.en = this -> en+d.en;
        return DDortgen;
    }

};


int main(void)
{
    dikdortgen d;
    d.SetBoy(180);
    d.SetEn(70);

    dikdortgen x;
    x.SetBoy(120);
    x.SetEn(50);
    dikdortgen toplam =x+d;
    cout<< d.GetBoy();
    cout<< "Boy: "<< toplam.GetBoy() << "En: " << toplam.GetEn() << endl;

    return 0;
}