#include <iostream>

// OVERLOADİNG

using namespace std;

class insan{
    private:
    int boy;
    int kilo;
    public:
    void setBoy(int x){ // 180 cm
        boy=x;
    }

    void setBoy(float x){ // 1.80 m
        boy=x*100;
    }

    int getBoy(){
        return boy;
    }

};

int main ()
{
    insan ali;
    ali.setBoy(180);
    float b = 1.85;
    ali.setBoy(b);

    cout<< ali.getBoy() << endl;

    return 0;
}