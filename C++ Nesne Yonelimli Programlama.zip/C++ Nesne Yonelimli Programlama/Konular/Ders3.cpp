#include <iostream>

using namespace std;

class yemek{
public:
    int kalori;
    int fiyat;
    int gram;
    int isitmak(int sure){
        if(sure<300)
        kalori+=sure;
        else
        kalori=0;
    }

};

class insan{ // Class ismi "İnsan".
    public: 
    int boy;
    float kilo;
    int yas;
    int yemek(yemek y){ // method ismi "yemek". parantez içindeki yemek ise class adıdır.
        kilo += y.kalori/(float)7000;
    }
};

int main()
{
    yemek sandvic;
    sandvic.kalori=300;
    sandvic.fiyat=10;
    sandvic.gram=100;

    insan ali; // Object ismi "ali".
    ali.boy = 175;
    ali.kilo = 80;
    ali.yas = 30;

    cout<< "Boy: "<< ali.boy << "Kilo: " << ali.kilo << "Yas: "<< ali.yas << endl;

    ali.yemek(sandvic);

    cout<< "Boy: "<< ali.boy << "Kilo: " << ali.kilo << "Yas: "<< ali.yas << endl;

    insan veli; // Object ismi "veli".
    veli.boy = 195;
    veli.kilo = 65;
    veli.yas = 64;

    cout<< "Boy: " << veli.boy << "Kilo: " << veli.kilo << "Yas: " << veli.yas << endl;

    sandvic.isitmak(100);

    veli.yemek(sandvic);

    cout<< "Boy: " << veli.boy << "Kilo: " << veli.kilo << "Yas: " << veli.yas << endl;

}