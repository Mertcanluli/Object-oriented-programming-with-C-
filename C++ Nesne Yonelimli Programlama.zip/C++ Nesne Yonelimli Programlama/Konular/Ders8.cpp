#include <iostream>

using namespace std;

class insan{
    private:
    int boy;
    int kilo;
    public:
    insan(){
        boy=10;
        kilo=1;
    }
    insan(int b){
        boy=b;
    }
    insan(int b, int k){
        boy=b;
        kilo=k;
    }
    void setBoy(int b){
        boy=b;
    }
    int getBoy(){
        return boy;
    }

};

int main()
{
    insan ali;
    insan veli(170,70);
    cout<< "Ali boy: "<< ali.getBoy() << "Veli boy: " << veli.getBoy() << endl;
    return 0;
}